﻿namespace _01.Loader.Models
{
    public enum BaseEntityStatus
    {
        InStore,
        Reserved,
        PendingFunds,
        Payed,
        Sold
    }
}
